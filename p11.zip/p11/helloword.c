#include <stdio.h>

void helloworld(void)
{
	printf("hello, world\n");
}
