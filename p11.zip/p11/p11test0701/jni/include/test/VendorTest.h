#ifndef _HD_VENDOR_H_
#define _HD_VENDOR_H_

bool xtest_ZUCPerformance_modify(int, int, const char*, int);
bool Test_SetTransmitDelay();


#endif