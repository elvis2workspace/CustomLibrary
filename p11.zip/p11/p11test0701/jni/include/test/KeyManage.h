
#ifndef KEYMANAGER_H_
#define KEYMANAGER_H_


#ifdef __cplusplus
extern "C" {
#endif

#if 0
void Test_KeyManage();
#else
/*key wrap����*/
bool test_keymanager();

#endif 

#ifdef __cplusplus
}
#endif


#endif