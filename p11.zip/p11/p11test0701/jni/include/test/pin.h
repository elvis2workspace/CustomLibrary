
#ifndef PIN_H_
#define PIN_H_

#ifdef __cplusplus
extern "C" {
#endif
/*pin����*/
CK_RV test_pin();

#ifdef __cplusplus
}
#endif

#endif