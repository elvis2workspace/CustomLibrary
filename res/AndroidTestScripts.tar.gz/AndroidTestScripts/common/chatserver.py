"""The most basic chat protocol possible.

run me with twistd -y chatserver.py, and then connect with multiple
telnet clients to port 1025
"""


from twisted.internet.protocol import Factory
from twisted.internet import reactor
from twisted.protocols.basic import LineReceiver
import logging
import logging.config

# create logger
logger = logging.getLogger('administrator')

class MyChat(LineReceiver):
    
    def __init__(self, users):
        self.users = users
        self.name = None
        self.state = "GETNAME"
        logging.config.fileConfig('D:\workspace\mgAuto\src\logging.conf')

        
    def connectionMade(self):
        self.sendLine("What's your name?")

    def connectionLost(self, reason):
        if self.name in self.users:
            del self.users[self.name]

    def lineReceived(self, line):
        if self.state == "GETNAME":
            self.handle_GETNAME(line)
        else:
            self.handle_CHAT(line)

    def handle_GETNAME(self, name):
        if name in self.users:
            self.sendLine("Name taken, please choose another.")
            return
        self.sendLine("Welcome, %s!" % (name,))
        logger.info('Attention, %s is login!' %(name,))
        self.name = name
        self.users[name] = self
        self.state = "CHAT"
    
    def handle_CHAT(self, message):
        message = "<%s> %s" % (self.name, message)
        for name, protocol in self.users.iteritems():
            if protocol != self:
                protocol.sendLine(message)
                # 'application' code
                logger.debug('just a test!')
class ChatFactory(Factory):
    
    def __init__(self):
        self.users = {} #maps user name to Chat instances
        
    def buildProtocol(self, addr):
        return MyChat(self.users)

# listenTCP is the method which connects a Factory to the network_utils.
reactor.listenTCP(8123, ChatFactory())
reactor.run()