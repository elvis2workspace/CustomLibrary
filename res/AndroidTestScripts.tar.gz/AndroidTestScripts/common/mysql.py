#coding=utf-8
'''
Created on 2015年3月26日

@author: Administrator
'''
#!/usr/bin/env python


import MySQLdb
