# ecoding=utf-8
a = '钱伟.qwer'
# a = a.decode('utf-8')
b = []
qie = a.split('.')
for x in qie:
    print x[1:2]

