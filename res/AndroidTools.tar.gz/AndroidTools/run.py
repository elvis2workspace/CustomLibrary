# ecoding=utf-8
import gui

__author__ = "Sven_Weng"

if __name__ == '__main__':
    g = gui.AndroidTools()
